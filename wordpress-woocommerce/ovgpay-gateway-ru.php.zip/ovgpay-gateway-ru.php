<?php
/*
 * Plugin Name: Платёжный плагин OVG-pay для WooCommerce 
 * Description: Принимайте оплату OVG у себя на сайте!
 * Author: Mr. Overgold
 * Author URI: https://overgold.app
 * Version: 1.0.1
 *
 */

add_filter('woocommerce_payment_gateways', 'ovgpay_register_gateway_class');

function ovgpay_register_gateway_class($gateways)
{
    $gateways[] = 'WC_OVGpay_Gateway';
    return $gateways;
}

add_action('plugins_loaded', 'ovgpay_gateway_class');

function ovgpay_gateway_class()
{
    if( isset($_GET[ 'order_id' ]) ) {
        (integer) $order_id = $_GET[ 'order_id' ];
        $order = wc_get_order($order_id);
        // $order->update_status('complited');
        // wp_schedule_single_event( time() + 600, 'true_hook_1' ); // 600 секунд это 10 минут, если кто не знал :)
    }

    class WC_OVGpay_Gateway extends WC_Payment_Gateway
    {
        public function __construct()
        {

            $this->id = 'ovgpay';
            $this->icon = 'https://ovgpay.overgold.app/img/logo.svg';
            $this->method_title = 'Оплата OVG-pay';
            $this->method_description = 'Плагин OVG-pay для использования оплаты в woocommerce';

            $this->init_form_fields();
            $this->init_settings();
            $this->title = $this->settings['title'];
            $this->description = $this->settings['description'];
            $this->enabled = $this->get_option('enabled');
            $this->redirect_page_id = $this->settings['returnUrl'];
            $this->serviceUrl = $this->settings['returnUrl'];
            $this->merchant = $this->settings['merchant'];
            $this->api = $this->settings['api'];

            $this->signature = $this->settings['signature'];
            $this->signature2 = $this->settings['signature2'];
            $this->signature3 = $this->settings['signature3'];
            add_action('woocommerce_api_' . strtolower(get_class($this)), array($this, 'check_ovgpay_response'));
            add_action('woocommerce_api_wc_ovgpay_gateway', array($this, 'check_ovgpay_response'));
            add_action('woocommerce_api_wc_ovgpay', 'check_ovgpay_response' );

            add_action('check_scheduled_hook', array($this, 'check_scheduled'));

            add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
            add_action('woocommerce_receipt_ovgpay', array(&$this, 'receipt_page'));
        }
        public function init_form_fields()
        {
            $this->form_fields = array(
                'enabled' => array(
                    'title'       => 'Включен/Выключен',
                    'label'       => 'Включить OVG-pay плагин',
                    'type'        => 'checkbox',
                    'description' => '',
                    'default'     => 'no'
                ),
                'title' => array(
                    'title'       => 'Заголовок',
                    'type'        => 'text',
                    'description' => 'Это то, что пользователь увидит как название метода оплаты на странице оформления заказа.',
                    'default'     => 'Оплата при помощи OVG Pay',
                    'desc_tip'    => true,
                ),
                'description' => array(
                    'title'       => 'Описание',
                    'type'        => 'textarea',
                    'description' => 'Описание этого метода оплаты, которое будет отображаться пользователю на странице оформления заказа.',
                    'default'     => 'Возможность оплачивать токенами сетей BSC, ETH, а также криптовалютой OverGold',
                ),
                'returnUrl' => array(
                    'title' => 'Return URL',
                    'type' => 'text',
                    'description' => 'URL of success page',
                    'default' => '',
                    'desc_tip' => true
                ),
                'merchant' => array(
                    'title'       => 'ID магазина',
                    'type'        => 'text'
                ),
                'api' => array(
                    'title'       => 'API-key',
                    'type'        => 'text'
                ),
                'signature' => array(
                    'title'       => 'URL OVG Pay API',
                    'type'        => 'text',
                    'default'       => 'https://wallet.overgold.app/v4/ovg-pay/'
                ),
                'signature2' => array(
                    'title'       => 'URL конвертера валют',
                    'type'        => 'text',
                    'default'       => 'https://wallet.overgold.app/v4/rs/price/up/'
                ),
                'signature3' => array(
                    'title'       => 'URL модуля оплаты',
                    'type'        => 'text',
                    'default'       => 'https://pay.overgold.app/'
                ),
                'returnUrl' => array(
                    'title' => 'Return URL',
                    'type' => 'select',
                    'options' => $this->ovgpay_get_pages('Select Page'),
                    'description' => 'URL of success page',
                    'desc_tip' => true
                )
            );
        }

        function receipt_page($order)
        {
            global $woocommerce;

            echo '<p>Спасибо за ваш заказ, сейчас вы будете перенаправлены на страницу оплаты OVG Pay</p>';
            echo $this->generate_ovgpay_form($order);

            $woocommerce->cart->empty_cart();
        }

        public function generate_ovgpay_form($order_id)
        {
            $order = new WC_Order($order_id);

            $description = 'Order №' . $order_id;
            // $callbackURL = $this->getCallbackUrls($order_id);
            $callbackURL = $this->getCallbackUrl(true, $order_id);
            $redirectURL = $this->getCallbackUrl(true, $order_id);
            $url_api_ovg  = $this->signature;
            $url_conver_ovg  = $this->signature2;
            $url_pay_ovg  = $this->signature3;
            $idmarket = $this->merchant;
            $apikay  = $this->api;
            $amount = str_replace(',', '.', $order->get_total());
            $currency_code = get_woocommerce_currency();

            $curl = curl_init();
            curl_setopt_array($curl, array(
                CURLOPT_URL => $url_conver_ovg . $currency_code . '/' . $amount . '/OVG/',
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => '',
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 0,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => 'GET',
                CURLOPT_HTTPHEADER => array(
                    'Cookie: route=24ba5ca1f54a31753eb55e1d335849ad5c9d723e'
                ),
            ));

            $response = curl_exec($curl);
            $total = json_decode($response, true);
            $amounts = $total["result"]["coins"];
            curl_close($curl);


            $urlsend = $url_api_ovg . 'shops/' . $idmarket . '/checkouts';

            $curl = curl_init();

            curl_setopt_array($curl, array(
                CURLOPT_URL => $urlsend,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => '',
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 0,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => 'POST',
                CURLOPT_POSTFIELDS => '{
        "orderID": "' . $order_id . '",
        "amount": ' . $amounts . ',
        "description": "' . $description . '",
        "callbackURL": "' . $callbackURL . '",
        "redirectURL": "' . $redirectURL . '"
    }',
                CURLOPT_HTTPHEADER => array(
                    'X-API-Key:' . $apikay,
                    'Content-Type: application/json',
                    'Cookie: route=24ba5ca1f54a31753eb55e1d335849ad5c9d723e'
                ),
            ));

            $response = curl_exec($curl);

            curl_close($curl);


            $responseifo = json_decode($response);
            $idpay = $responseifo->{'checkoutID'};


            $urlpay = $url_pay_ovg .  $idpay;

            $fp = fopen("log.txt", "w");
            fwrite($fp, $urlpay);
            fclose($fp);

            curl_close($curl);

            // $order->add_order_note( 'Ссылка для оплаты: '.$urlpay, true );
            $order->add_order_note( 'Ссылка для оплаты: <a href="'.$urlpay.'" target="blank">'.$urlpay.'</a>', true );
            // $order->update_meta_data("checkout_id", $idpay);
            $this->check_scheduled($order_id);
            // $this->check_scheduled($idpay, $order_id);
            // do_action('check_sched_hook', $order_id);

            return $this->fillPayForm($urlpay);
        }

        public function fillPayForm($urlpay)
        {
            return $this->generateForm($urlpay);
        }

        protected function generateForm($urlpay)
        {


            $button = '<script>
		function submitWayForPayForm()
		{
			window.location.href = "' . $urlpay . '";
		}
		setTimeout( submitWayForPayForm, 200 );
	</script>';

            return $button;
        }


        function payment_fields()
        {
            if ($this->description) {
                echo wpautop(wptexturize($this->description));
            }
        }

        function process_payment($order_id)
        {
            $order = new WC_Order($order_id);

            if (version_compare(WOOCOMMERCE_VERSION, '2.1.0', '>=')) {
                /* 2.1.0 */
                $checkout_payment_url = $order->get_checkout_payment_url(true);
            } else {
                /* 2.0.0 */
                $checkout_payment_url = get_permalink(get_option('woocommerce_pay_page_id'));
            }

            WC()->cart->empty_cart();

            return array(
                'result' => 'success',
                'redirect' => add_query_arg('order', $order->id, add_query_arg('key', $order->order_key, $checkout_payment_url))
            );
        }

        private function check_ovgpay_response()
        {
            $order = wc_get_order($_GET['id']);
            // $order = new WC_Order($_GET['id']);

            //  $order->update_status('completed');
            $order->update_status('processing');
            $order->payment_complete();
        }


        private function getCallbackUrls($orderId)
        {
            $callback = get_permalink($this->redirect_page_id)."?order_id=" . $orderId;
            return $callback;
        }

        // private function check_scheduled($checkoutId, $orderId, $i = 0)
        private function check_scheduled($orderId, $checkoutId = NULL, $i = 0)
        {
            if (!isset($checkoutId)) {
                $order = wc_get_order($orderId);
                $meta = $order->get_meta_data();
                $checkoutId = $meta["checkout_id"];
            }
            add_action('check_scheduled_hook', array($this, 'check_scheduled'));
            $url_checkout_id = $url_api_ovg . 'checkouts/' . $checkoutId;

            $curl = curl_init();

            curl_setopt_array($curl, array(
                CURLOPT_URL => $url_checkout_id,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => '',
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 0,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => 'GET',
                CURLOPT_HTTPHEADER => array(
                    'X-API-Key:' . $apikay,
                    'Content-Type: application/json'
                ),
            ));

            $response = curl_exec($curl);

            curl_close($curl);

            $responseifo = json_decode($response);
            $checkout_status = $responseifo->{'status'};

            switch ($checkout_status) {
                case 20:
                    # Оплачен
                    echo $orderId;
                    $order = wc_get_order($orderId);
                    // $order->update_status('processing');
                    $order->update_status('completed');
                    $msg = 'Успешная оплата';
                    $order->add_order_note( $msg , false );
                    $order->payment_complete();
                break;
                
            ///////////////
            // Неуспешные кейсы
                case 40:
                    # Фейлед
                    $order = wc_get_order($orderId);
                    $msg = 'Оплата фейлед';
                    $order->add_order_note( $msg , false );
                    $order->update_status('failed');
                break;
                
                case 50:
                    # экспайред
                    $order = wc_get_order($orderId);
                    $msg = 'Оплата фейлед';
                    $order->add_order_note( $msg , false );
                    $order->update_status('failed');
                break;
                
                case -10:
                    # делитед
                    $order = wc_get_order($orderId);
                    $msg = 'Оплата фейлед';
                    $order->add_order_note( $msg , false );
                    $order->update_status('failed');
                break;
            // Неуспешные кейсы - конец
            ///////////////

                default:
                    # Ожидает оплаты, пендинг и др.
                    $order = wc_get_order($orderId);
                    // $order->update_status('processing');
                    $msg = 'Нет информации по оплате заказа. Оплату можно проверить перейдя по ссылке ниже';
                    $order->add_order_note( $msg , false );
                    // sleep(30);
                    // if ($i <= 5) {
                    //     check_scheduled($checkoutId, $orderId, $i += 1);
                    // }
                    // wp_schedule_single_event( time() + 120, 'check_scheduled_hook', array($checkoutId, $orderId) );
                break;
            }

            return;
        }

        private function getCallbackUrl($service = false, $order_id = NULL)
        {
            $redirect_url = ($this->redirect_page_id == "" || $this->redirect_page_id == 0) ? get_site_url() . "/" : get_permalink($this->redirect_page_id);
            // $order_id
            if (!$service) {
                if (
                    isset($this->settings['returnUrl']) &&
                    trim($this->settings['returnUrl']) !== ''
                ) {
                    return trim($this->settings['returnUrl']);
                }
                return $redirect_url;
            }
            if (isset($order_id)) {
                $redirect_url = add_query_arg( array('order_id' => $order_id), $redirect_url );
            }

            return $redirect_url;
        }


        // get all pages
        function ovgpay_get_pages($title = false, $indent = true)
        {
            $wp_pages = get_pages('sort_column=menu_order');
            $page_list = array();
            if ($title) {
                $page_list[] = $title;
            }
            foreach ($wp_pages as $page) {
                $prefix = '';
                // show indented child pages?
                if ($indent) {
                    $has_parent = $page->post_parent;
                    while ($has_parent) {
                        $prefix .= ' - ';
                        $next_page = get_page($has_parent);
                        $has_parent = $next_page->post_parent;
                    }
                }
                // add to page list array array
                $page_list[$page->ID] = $prefix . $page->post_title;
            }
            return $page_list;
        }
    }
}
