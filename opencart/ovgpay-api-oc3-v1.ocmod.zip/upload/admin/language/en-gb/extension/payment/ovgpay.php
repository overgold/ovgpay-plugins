<?php
// Heading
$_['heading_title']		 = 'ovg pay';

// Text
$_['text_extension']	 = 'Extension';
$_['text_success']		 = 'Success: You have modified ovg account details!';
$_['text_edit']          = 'Edit ovg';
$_['text_pay']			 = 'ovg';
$_['text_card']			 = 'Credit Card';

// Entry
$_['entry_merchant']	 = 'ID market';
$_['entry_signature']	 = 'URL ovg Pay API';
$_['entry_signature2']	 = 'URL currency converter';
$_['entry_signature3']	 = 'URL payment module';
$_['entry_api']	         = 'API-key';

$_['entry_order_status'] = 'Status on successful payment';
$_['entry_order_status_failed'] = 'Status on failed payment';
$_['entry_order_status_wait'] = 'Pending payment status';
$_['entry_status']		 = 'Status';
$_['entry_sort_order']	 = 'Sort Order';

// Help
$_['help_total']		 = 'The checkout total the order must reach before this payment method becomes active.';

// Error
$_['error_permission']	 = 'Warning: You do not have permission to modify payment ovg pay!';
$_['error_merchant']	 = 'ID market Required!';
$_['error_signature']	 = 'Host ovg Pay Required!';
$_['error_api']	         = 'API Required!';


$_['text_ovgpay']		 = '<img src="view/image/payment/OVGPay.png" height="20" alt="ovgpay" title="ovgpay" />';