<?php
// Heading
$_['heading_title']		 = 'ovg pay';

// Text
$_['text_extension']	 = 'Расширения';
$_['text_success']		 = 'Данные учетной записи ovg успешно изменены!';
$_['text_edit']          = 'Изменить ovg';
$_['text_pay']			 = 'ovg';
$_['text_card']			 = 'Кредитная карта';


// Entry
$_['entry_merchant']	 = 'ID магазина';
$_['entry_signature']	 = 'URL ovg Pay API';
$_['entry_signature2']	 = 'URL конвертера валют';
$_['entry_signature3']	 = 'URL модуля оплаты';
$_['entry_api']	         = 'API-key';
$_['entry_type']		 = 'Тип';
$_['entry_total']		 = 'Итого';
$_['entry_order_status'] = 'Статус успешной оплаты';
$_['entry_order_status_failed'] = 'Статус неудачной оплаты';
$_['entry_order_status_wait'] = 'Статус ожидания оплаты';

$_['entry_status']		 = 'Статус';
$_['entry_sort_order']	 = 'Порядок сортировки';


// Error
$_['error_permission']	 = 'Внимание: недостаточно прав для изменения способа оплаты LIQPAY!';
$_['error_merchant']	 = 'Требуется указать ID магазина!';
$_['error_signature']	 = 'Требуется указать URL ovg Pay API!';
$_['error_signature2']	 = 'Требуется указать URL конвертера валют!';
$_['error_signature3']	 = 'Требуется указать URL модуля оплаты!';
$_['error_api']	         = 'Требуется указать API-key!';




$_['text_ovgpay']		 = '<img src="view/image/payment/OVGPay.png" height="20" alt="ovgpay" title="ovgpay" />';