<?php
class ControllerExtensionPaymentOVGPay extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('extension/payment/ovgpay');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('setting/setting');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
			$this->model_setting_setting->editSetting('payment_ovgpay', $this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$this->response->redirect($this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment', true));
		}

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->error['merchant'])) {
			$data['error_merchant'] = $this->error['merchant'];
		} else {
			$data['error_merchant'] = '';
		}

		if (isset($this->error['signature'])) {
			$data['error_signature'] = $this->error['signature'];
		} else {
			$data['error_signature'] = '';
		}


		if (isset($this->error['signature2'])) {
			$data['error_signature2'] = $this->error['signature2'];
		} else {
			$data['error_signature2'] = '';
		}


		if (isset($this->error['signature3'])) {
			$data['error_signature3'] = $this->error['signature3'];
		} else {
			$data['error_signature3'] = '';
		}

		if (isset($this->error['api'])) {
			$data['error_api'] = $this->error['api'];
		} else {
			$data['error_api'] = '';
		}

		

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_payment'),
			'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment', true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('extension/payment/ovgpay', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['action'] = $this->url->link('extension/payment/ovgpay', 'user_token=' . $this->session->data['user_token'], true);

		$data['cancel'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment', true);

		if (isset($this->request->post['payment_ovgpay_merchant'])) {
			$data['payment_ovgpay_merchant'] = $this->request->post['payment_ovgpay_merchant'];
		} else {
			$data['payment_ovgpay_merchant'] = $this->config->get('payment_ovgpay_merchant');
		}

		if (isset($this->request->post['payment_ovgpay_signature'])) {
			$data['payment_ovgpay_signature'] = $this->request->post['payment_ovgpay_signature'];
		} else if(!empty($this->config->get('payment_ovgpay_signature'))) {
			$data['payment_ovgpay_signature'] = $this->config->get('payment_ovgpay_signature');
		}else{
			$data['payment_ovgpay_signature'] = 'https://wallet.overgold.app/v4/ovg-pay/';
		}

		if (isset($this->request->post['payment_ovgpay_signature2'])) {
			$data['payment_ovgpay_signature2'] = $this->request->post['payment_ovgpay_signature2'];
		} else if(!empty($this->config->get('payment_ovgpay_signature2'))) {
			$data['payment_ovgpay_signature2'] = $this->config->get('payment_ovgpay_signature2');
		}else{
			$data['payment_ovgpay_signature2'] = 'https://wallet.overgold.app/v4/rs/price/up/';
		}

		if (isset($this->request->post['payment_ovgpay_signature3'])) {
			$data['payment_ovgpay_signature3'] = $this->request->post['payment_ovgpay_signature3'];
		} else if(!empty($this->config->get('payment_ovgpay_signature3'))) {
			$data['payment_ovgpay_signature3'] = $this->config->get('payment_ovgpay_signature3');
		}else{
			$data['payment_ovgpay_signature3'] = 'https://pay.overgold.app/';
		}

		 if (isset($this->request->post['payment_ovgpay_api'])) {
		 	$data['payment_ovgpay_api'] = $this->request->post['payment_ovgpay_api'];
		 } else {
		 	$data['payment_ovgpay_api'] = $this->config->get('payment_ovgpay_api');
		 }


		

		

		

		if (isset($this->request->post['payment_ovgpay_order_status_id'])) {
			$data['payment_ovgpay_order_status_id'] = $this->request->post['payment_ovgpay_order_status_id'];
		} else {
			$data['payment_ovgpay_order_status_id'] = $this->config->get('payment_ovgpay_order_status_id');
		}

		
		$this->load->model('localisation/order_status');

		$data['order_statuses'] = $this->model_localisation_order_status->getOrderStatuses();

		

		if (isset($this->request->post['payment_ovgpay_status'])) {
			$data['payment_ovgpay_status'] = $this->request->post['payment_ovgpay_status'];
		} else {
			$data['payment_ovgpay_status'] = $this->config->get('payment_ovgpay_status');
		}

		if (isset($this->request->post['payment_ovgpay_sort_order'])) {
			$data['payment_ovgpay_sort_order'] = $this->request->post['payment_ovgpay_sort_order'];
		} else {
			$data['payment_ovgpay_sort_order'] = $this->config->get('payment_ovgpay_sort_order');
		}

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('extension/payment/ovgpay', $data));
	}

	protected function validate() {
		if (!$this->user->hasPermission('modify', 'extension/payment/ovgpay')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		if (!$this->request->post['payment_ovgpay_merchant']) {
			$this->error['merchant'] = $this->language->get('error_merchant');
		}

		if (!$this->request->post['payment_ovgpay_signature']) {
			$this->error['signature'] = $this->language->get('error_signature');
		}

		if (!$this->request->post['payment_ovgpay_signature2']) {
			$this->error['signature2'] = $this->language->get('error_signature2');
		}
		if (!$this->request->post['payment_ovgpay_signature3']) {
			$this->error['signature3'] = $this->language->get('error_signature3');
		}

		if (!$this->request->post['payment_ovgpay_api']) {
			$this->error['api'] = $this->language->get('error_api');
		}

		return !$this->error;
	}
}