<?php
// Text
$_['text_title'] = 'OVG pay';
