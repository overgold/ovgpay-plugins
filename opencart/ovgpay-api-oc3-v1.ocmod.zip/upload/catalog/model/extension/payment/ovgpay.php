<?php
class ModelExtensionPaymentOVGpay extends Model {
	public function getMethod($address, $total) {
		$this->load->language('extension/payment/ovgpay');


		$method_data = array();

			$method_data = array(
				'code'       => 'ovgpay',
				'title'      => $this->language->get('text_title'),
				'terms'      => '',
				'sort_order' => $this->config->get('payment_ovgpay_sort_order')
			);

		return $method_data;
	}
}
